/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package testaridade;

/**
 *
 * @author aluno
 */
import java.util.Scanner;
public class Testaridade {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int idade;
        
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Digite sua idade: ");
        idade = sc.nextInt();
        
        if (idade >= 18) {
        System.out.print("Maior de idade.");
        } else {
        System.out.print("Menor de idade.");
        }
    }
    
}
