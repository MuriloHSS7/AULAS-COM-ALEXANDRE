/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package programademedia;

/**
 *
 * @author aluno
 */
public class Programademedia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int var1 = 15;
        int var2 = 18;
        int var3 = 20;
        int varm = var1 + var2 + var3;
        System.out.println(var1);
        System.out.println(var2);
        System.out.println(var3);
        System.out.println(var1 + var2 + var3);
        System.out.println(varm / 3);
    }
    
}
