/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package classefuncionarios;

public class ClasseFuncionarios {
    
    public static void main(String[] args) {
        
        class funcionario{
            
            String nome;
            String departamento;
            double salario;
            String dataentradabanco;
            String rg;
        }
    }
}