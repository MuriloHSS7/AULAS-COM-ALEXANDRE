/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package soma1a100;

/**
 *
 * @author aluno
 */
public class Soma1a100 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int cont;
        int soma;
        
        cont = 0;
        soma = 0;
        
        while(cont < 100) {
        cont = cont + 1;
        soma = cont + soma;
        System.out.println("A soma de todos os numeros e: " + cont);
        }
    }
    
}
