/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package metodo41;

/**
 *
 * @author aluno
 */
public class Metodo41 {
    String nome, dep, empresa, RG;
    double salario;

    void recebeAumento(double percentual) {
        salario += salario * percentual / 100;
    }

    public double calculaGanhoAnual() {
        return salario * 12;
    }
    public static void main(String[] args) {
        Metodo41 f1 = new Metodo41();
        f1.nome = "Murilo";
        f1.dep = "Rede de Seguranca";
        f1.empresa = "Grupo Saga Wolksvagen";
        f1.RG = "798956-5";
        f1.salario = 15000.0;

        // Aumento de 2000 reais
        f1.recebeAumento(2000);

        System.out.println("Nome: " + f1.nome +
                           "\nDepartamento: " + f1.dep +
                           "\nEmpresa: " + f1.empresa +
                           "\nRG: " + f1.RG +
                           "\nSalario Anual: " + f1.calculaGanhoAnual());
    }
}