/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package programaretangulo;

/**
 *
 * @author aluno
 */
public class Programaretangulo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int var1 = 15;
        int var2 = 15;
        int vara = var1 * var2;
        System.out.print("Essa e a area do retangulo: ");
        System.out.println(vara);
        
    }
    
}
