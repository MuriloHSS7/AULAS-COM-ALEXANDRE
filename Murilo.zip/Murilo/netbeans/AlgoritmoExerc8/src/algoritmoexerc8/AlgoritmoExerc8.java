/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package algoritmoexerc8;

/**
 *
 * @author aluno
 */

import java.util.Scanner;

public class AlgoritmoExerc8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        String nome;
        int idade;
        double valor;
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite seu nome: ");
        nome = sc.nextLine();
        
        System.out.println("Digite sua idade: ");
        idade = sc.nextInt();
        
        System.out.println("Digite seu salario: ");
        valor = sc.nextDouble();
        
        System.out.println("O funcionario " + nome + " tem "
        + idade + " anos e recebe um salario de " + valor + " reais.");
        
    }
    
}
