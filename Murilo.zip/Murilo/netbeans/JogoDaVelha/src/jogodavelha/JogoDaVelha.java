package jogodavelha;

import java.util.Scanner;

public class JogoDaVelha {
    
    public static void main(String[] args) {
        
        char[][] tabuleiro = new char[3][3];
        Scanner entrada = new Scanner(System.in);

        // Inicializa o tabuleiro com espaços em branco
        for (int cont = 0; cont < 3; cont=cont+1) {
            for (int cont2 = 0; cont2 < 3; cont2=cont2+1) {
                tabuleiro[cont][cont2] = ' ';
            }
        }

        // Exibe o tabuleiro
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(tabuleiro[i][j] + " ");
            }
            System.out.println();
        }

        // Loop principal do jogo
        while (true) {
            System.out.println("\nSua jogada (1 a 9): ");
            int jogada = entrada.nextInt();

            // Verifica se a jogada é válida
            if (jogada >= 1 && jogada <= 9) {
                int linha = (jogada - 1) / 3;
                int coluna = (jogada - 1) % 3;

                if (tabuleiro[linha][coluna] == ' ') {
                    tabuleiro[linha][coluna] = 'X';
                } else {
                    System.out.println("Essa posição já está ocupada. Tente novamente.");
                }
            } else {
                System.out.println("Jogada inválida. Escolha um número entre 1 e 9.");
            }

            // Exibe o tabuleiro atualizado
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    System.out.print(tabuleiro[i][j] + " ");
                }
                System.out.println();
            }
        }
    }
}