/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package carro;

/**
 *
 * @author aluno
 */
public class Carro {
    
    String modelo;
    String cor;
    String ano;
    String fabricante;
    double preco;
    
    void ComprarCarro(double PrecoCompletoOpcionais){
        double NovoModelo = this.preco - PrecoCompletoOpcionais;
        this.preco = NovoModelo;
    }
    
    public static void main(String[] args) {
        Carro car = new Carro();
        car.modelo = "Polo";
        car.cor = "Prata";
        car.ano = "2020";
        car.fabricante = "Volkswagen";
        car.preco = 60000.00;
        car.ComprarCarro(15000.00);

        car.modelo = "Bugatti";
        car.cor = "Azul";
        car.ano = "2024";
        car.fabricante = "Bugatti";
        car.preco = 5000000.00;
        car.ComprarCarro(200000.00);
    }
}
