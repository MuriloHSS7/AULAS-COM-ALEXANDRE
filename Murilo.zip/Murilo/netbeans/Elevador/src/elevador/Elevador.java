package elevador;

import java.util.Scanner;

public class Elevador {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        
        System.out.println("Bem vindo ao elevador! Escolha um andar de 1 a 5.");
        int andar = in.nextInt();
        
        switch (andar){
            case 1:
                System.out.println("voce escolheu o " + andar + " andar.");
                break;
            case 2:
                System.out.println("voce escolheu o " + andar + " andar.");
                break;
            case 3:
                System.out.println("voce escolheu o " + andar + " andar.");
                break;
            case 4:
                System.out.println("voce escolheu o " + andar + " andar.");
                break;
            case 5:
                System.out.println("voce escolheu o " + andar + " andar.");
                break;
            default:    
                System.out.println("O "+ andar +" andar nao existe, escolha um andar valido!");
                break;
        }
    }
}
