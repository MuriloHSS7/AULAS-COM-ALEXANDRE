/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dezmil;

public class Dezmil {

    public static void main(String[] args) {
        
        int vetor[] = new int[10000];
        
        vetor[0] = 20;
        vetor[1] = 18;
        vetor[2] = 24;
        vetor[3] = 15;
        vetor[4] = 19;
        vetor[5] = 30;
        
        // laço de repetição
        for(int cont = 0; cont < vetor.length; cont = cont + 1) {
            System.out.println("Elemento " + cont + " : " + vetor[cont]);
        }
    }
}
