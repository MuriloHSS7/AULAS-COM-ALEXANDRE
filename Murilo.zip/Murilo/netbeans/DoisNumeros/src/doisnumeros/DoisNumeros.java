/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package doisnumeros;

/**
 *
 * @author aluno
 */
public class DoisNumeros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int Num1 = 2;
        int Num2 = 3;
        int resultado = 0;
        for (int cont = 0; cont < Num2; cont++){
        resultado=resultado + Num1;
        }
        System.out.println("O resultado e: " + resultado);
    }
}
