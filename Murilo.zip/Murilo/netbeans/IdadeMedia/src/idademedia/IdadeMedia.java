/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package idademedia;

import java.util.Scanner;
public class IdadeMedia {

    public static void main(String[] args) {
        Scanner output = new Scanner(System.in);
        
        int RecebeIdade[] = new int[10];
        double media = 0;
        double soma = 0;
        
        for (int cont = 0; cont < RecebeIdade.length; cont = cont + 1){
            System.out.print("Informe sua idade: ");
            RecebeIdade[cont] = output.nextInt();
            
            soma+=RecebeIdade[cont];
        }
        System.out.println();
        media = soma/10;
        System.out.println("A media das idades e: " + media);
    }
}
