/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exemploconta;

public class ExemploConta {
    
    int numero;
    String dono;
    double saldo;
    double limite;
    
    void sacar(double quantidade){
        double novoSaldo = this.saldo - quantidade;
        this.saldo = novoSaldo;
    }
    
    public static void main(String[] args){
        
        ExemploConta co = new ExemploConta();
        co.numero = 1234;
        co.dono = "Murilo";
        co.saldo = 100.00;
        co.limite = 1000.00;
        co.sacar(50.00);
    }
}
