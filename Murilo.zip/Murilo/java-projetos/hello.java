public class hello
{
    /*Meu primeiro programa Java */
    public static void main (string[] args) {
        //Mostra na tela o texto entre "..."
        System. Out. println("Este é o meu primeiro programa");
    }
}